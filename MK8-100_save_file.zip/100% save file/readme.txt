place the "mk8d_100percent_chainswordcs" folder inside "SD:\switch\checkpoint\saves\0x0100152000022000 Mario Kart 8 Deluxe"
then restore the backup using Checkpoint, which can be downloaded here: https://github.com/BernardoGiordano/Checkpoint/releases

this save file was dumped from the US english version of the game
it may be compatible with other regions (with a slightly different titleID, the long string of numbers) but that is untested by me